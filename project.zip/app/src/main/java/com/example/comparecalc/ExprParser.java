package com.example.comparecalc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/** 简单的四则运算表达式解析器，支持 + - * / 括号 小数 负号 百分号。 */
final class ExprParser {

    private static final MathContext MC = new MathContext(30);
    private static final BigDecimal HUNDRED = new BigDecimal(100);

    private final String s;
    private int pos = 0;
    private boolean lastPercent = false;
    private boolean termPercent = false;

    private ExprParser(String s) {
        this.s = s;
    }

    /** 计算表达式；表达式有误时返回 null。 */
    static BigDecimal evaluate(String text) {
        if (text == null) {
            return null;
        }
        String t = text.replaceAll("\\s", "")
                .replace(",", "")
                .replace('\u00d7', '*')
                .replace('\u00f7', '/')
                .replace('\u2212', '-')
                .replace('\uff08', '(')
                .replace('\uff09', ')')
                .replace('\uff0b', '+')
                .replace('\uff0d', '-')
                .replace('\uff0a', '*')
                .replace('\uff0f', '/')
                .replace('\uff05', '%');
        if (t.isEmpty()) {
            return null;
        }
        try {
            ExprParser p = new ExprParser(t);
            BigDecimal v = p.expr();
            if (p.pos != t.length()) {
                return null;
            }
            return v.setScale(10, RoundingMode.HALF_UP);
        } catch (RuntimeException e) {
            return null;
        }
    }

    static String format(BigDecimal v) {
        if (v.signum() == 0) {
            return "0";
        }
        return v.stripTrailingZeros().toPlainString();
    }

    private BigDecimal expr() {
        BigDecimal v = term();
        while (pos < s.length()) {
            char c = s.charAt(pos);
            if (c == '+') {
                pos++;
                BigDecimal r = term();
                if (termPercent) {
                    r = v.multiply(r);
                }
                v = v.add(r);
            } else if (c == '-') {
                pos++;
                BigDecimal r = term();
                if (termPercent) {
                    r = v.multiply(r);
                }
                v = v.subtract(r);
            } else {
                break;
            }
        }
        return v;
    }

    private BigDecimal term() {
        BigDecimal v = factor();
        boolean pct = lastPercent;
        boolean single = true;
        while (pos < s.length()) {
            char c = s.charAt(pos);
            if (c == '*') {
                pos++;
                single = false;
                v = v.multiply(factor());
            } else if (c == '/') {
                pos++;
                single = false;
                v = v.divide(factor(), MC);
            } else {
                break;
            }
        }
        termPercent = single && pct;
        return v;
    }

    private BigDecimal factor() {
        if (pos >= s.length()) {
            throw new IllegalArgumentException("incomplete");
        }
        char c = s.charAt(pos);
        if (c == '-') {
            pos++;
            return factor().negate();
        }
        if (c == '+') {
            pos++;
            return factor();
        }
        BigDecimal v = primary();
        boolean pct = false;
        while (pos < s.length() && s.charAt(pos) == '%') {
            pos++;
            v = v.divide(HUNDRED, MC);
            pct = true;
        }
        lastPercent = pct;
        return v;
    }

    private BigDecimal primary() {
        if (pos >= s.length()) {
            throw new IllegalArgumentException("incomplete");
        }
        char c = s.charAt(pos);
        if (c == '(') {
            pos++;
            BigDecimal v = expr();
            if (pos >= s.length() || s.charAt(pos) != ')') {
                throw new IllegalArgumentException("missing )");
            }
            pos++;
            return v;
        }
        int start = pos;
        while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
            pos++;
        }
        if (start == pos) {
            throw new IllegalArgumentException("number expected");
        }
        return new BigDecimal(s.substring(start, pos));
    }
}
