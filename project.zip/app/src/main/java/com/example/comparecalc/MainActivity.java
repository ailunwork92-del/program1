package com.example.comparecalc;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private LinearLayout rowsContainer;
    private TextView resultView;
    private final List<EditText[]> inputs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("比较计算器");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("输入每件商品的价格和数量（重量/个数），比较谁的单价更划算。");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        hint.setPadding(0, dp(4), 0, dp(8));
        root.addView(hint);

        rowsContainer = new LinearLayout(this);
        rowsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(rowsContainer);
        addRow();
        addRow();

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, dp(16), 0, dp(8));

        Button addBtn = new Button(this);
        addBtn.setText("添加商品");
        addBtn.setOnClickListener(v -> addRow());
        buttons.addView(addBtn, weightParams());

        Button calcBtn = new Button(this);
        calcBtn.setText("计算");
        calcBtn.setOnClickListener(v -> calculate());
        buttons.addView(calcBtn, weightParams());

        Button clearBtn = new Button(this);
        clearBtn.setText("清空");
        clearBtn.setOnClickListener(v -> clearAll());
        buttons.addView(clearBtn, weightParams());

        root.addView(buttons);

        resultView = new TextView(this);
        resultView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        resultView.setPadding(0, dp(8), 0, 0);
        root.addView(resultView);

        setContentView(scroll);
    }

    private void addRow() {
        int index = inputs.size() + 1;

        TextView label = new TextView(this);
        label.setText("商品 " + index);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setPadding(0, dp(12), 0, dp(4));

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        EditText price = makeInput("价格");
        EditText qty = makeInput("数量/重量");
        line.addView(price, weightParams());
        line.addView(qty, weightParams());

        rowsContainer.addView(label);
        rowsContainer.addView(line);
        inputs.add(new EditText[]{price, qty});
    }

    private void clearAll() {
        rowsContainer.removeAllViews();
        inputs.clear();
        addRow();
        addRow();
        resultView.setText("");
    }

    private void calculate() {
        List<Integer> ids = new ArrayList<>();
        List<Double> units = new ArrayList<>();
        for (int i = 0; i < inputs.size(); i++) {
            double p = parse(inputs.get(i)[0]);
            double q = parse(inputs.get(i)[1]);
            if (p > 0 && q > 0) {
                ids.add(i + 1);
                units.add(p / q);
            }
        }

        if (ids.size() < 2) {
            resultView.setText("请至少填写两件商品的价格和数量（都要大于 0）。");
            return;
        }

        int best = 0;
        for (int i = 1; i < units.size(); i++) {
            if (units.get(i) < units.get(best)) {
                best = i;
            }
        }
        double min = units.get(best);

        StringBuilder sb = new StringBuilder();
        sb.append("✅ 最划算：商品 ").append(ids.get(best)).append("\n\n");
        for (int i = 0; i < ids.size(); i++) {
            sb.append("商品 ").append(ids.get(i))
                    .append("：单价 ")
                    .append(String.format(Locale.US, "%.4f", units.get(i)));
            if (i == best) {
                sb.append("（最低）");
            } else {
                double extra = (units.get(i) / min - 1) * 100;
                sb.append(String.format(Locale.US, "，贵 %.1f%%", extra));
            }
            sb.append("\n");
        }
        resultView.setText(sb.toString());
    }

    private double parse(EditText e) {
        try {
            return Double.parseDouble(e.getText().toString().trim());
        } catch (NumberFormatException ex) {
            return Double.NaN;
        }
    }

    private EditText makeInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
