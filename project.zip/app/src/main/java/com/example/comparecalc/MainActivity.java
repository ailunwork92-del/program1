package com.example.comparecalc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private static final String[] LABELS = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
    private static final int MIN_ROWS = 2;
    private static final int MAX_ROWS = 10;
    private static final int DEFAULT_ROWS = 5;
    private static final int MAX_HISTORY = 20;
    private static final String PREFS = "calc";
    private static final String KEY_STATE = "state";
    private static final String KEY_HISTORY = "history";

    private static class Row {
        LinearLayout box;
        TextView label;
        EditText edit;
        TextView result;
        String value;     // 算式有效时的结果文本
        boolean error;    // 算式不完整或有误
    }

    private final List<Row> rows = new ArrayList<>();
    private LinearLayout rowsContainer;
    private TextView compareView;
    private ScrollView scroll;
    private EditText current;
    private SharedPreferences prefs;
    private String compareCopyText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // 顶部标题栏
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(8), dp(8), dp(4));

        TextView title = new TextView(this);
        title.setText("比较计算器");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button historyBtn = new Button(this);
        historyBtn.setText("历史");
        historyBtn.setOnClickListener(v -> showHistory());
        header.addView(historyBtn);
        root.addView(header);

        // 中间可滚动区域
        scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(4), dp(16), dp(16));
        scroll.addView(content);

        TextView hint = new TextView(this);
        hint.setText("点一行输入算式，结果自动显示；填两行以上后点“比较”。点结果可复制。");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        hint.setPadding(0, 0, 0, dp(4));
        content.addView(hint);

        rowsContainer = new LinearLayout(this);
        rowsContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(rowsContainer);

        Button addRowBtn = new Button(this);
        addRowBtn.setText("+ 添加一行");
        addRowBtn.setOnClickListener(v -> addRowClicked());
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        addParams.topMargin = dp(12);
        content.addView(addRowBtn, addParams);

        compareView = new TextView(this);
        compareView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        compareView.setPadding(0, dp(16), 0, dp(8));
        compareView.setOnClickListener(v -> {
            if (!compareCopyText.isEmpty()) {
                copy(compareCopyText, "已复制比较结果");
            }
        });
        content.addView(compareView);

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(buildKeypad());
        setContentView(root);

        loadRows(loadState());
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    // ---------------------------------------------------------------- 行管理

    private void loadRows(List<String> exprs) {
        rowsContainer.removeAllViews();
        rows.clear();
        int n = Math.max(MIN_ROWS, Math.min(MAX_ROWS, exprs.size()));
        for (int i = 0; i < n; i++) {
            addRow(i < exprs.size() ? exprs.get(i) : "");
        }
        current = rows.get(0).edit;
        current.requestFocus();
        showCompare("", "");
    }

    private Row addRow(String initial) {
        final Row row = new Row();

        row.box = new LinearLayout(this);
        row.box.setOrientation(LinearLayout.VERTICAL);

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, dp(10), 0, 0);

        row.label = new TextView(this);
        row.label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        row.label.setTypeface(null, Typeface.BOLD);
        row.label.setWidth(dp(28));
        line.addView(row.label);

        row.edit = new EditText(this);
        row.edit.setHint("输入算式，如 58×99");
        row.edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        row.edit.setShowSoftInputOnFocus(false);
        row.edit.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                current = (EditText) v;
            }
        });
        row.edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                onEdited(row);
            }
        });
        line.addView(row.edit, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView del = new TextView(this);
        del.setText("删");
        del.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        del.setTextColor(color(R.color.delete_color));
        del.setPadding(dp(14), dp(8), dp(6), dp(8));
        del.setOnClickListener(v -> removeRow(row));
        line.addView(del);
        row.box.addView(line);

        row.result = new TextView(this);
        row.result.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.result.setPadding(dp(28), 0, 0, 0);
        row.result.setTextColor(color(R.color.result_default));
        row.result.setOnClickListener(v -> {
            if (row.value != null) {
                copy(row.value, "已复制：" + row.value);
            }
        });
        row.box.addView(row.result);

        rowsContainer.addView(row.box);
        rows.add(row);
        relabel();

        if (initial != null && !initial.isEmpty()) {
            row.edit.setText(initial);
        }
        return row;
    }

    private void relabel() {
        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).label.setText(LABELS[i]);
        }
    }

    private void addRowClicked() {
        if (rows.size() >= MAX_ROWS) {
            toast("最多 " + MAX_ROWS + " 行");
            return;
        }
        final Row row = addRow("");
        current = row.edit;
        row.edit.requestFocus();
        scroll.post(() -> scroll.smoothScrollTo(0, rowsContainer.getTop() + row.box.getTop()));
    }

    private void removeRow(Row row) {
        if (rows.size() <= MIN_ROWS) {
            toast("至少保留 " + MIN_ROWS + " 行");
            return;
        }
        rowsContainer.removeView(row.box);
        rows.remove(row);
        relabel();
        if (current == row.edit) {
            current = rows.get(0).edit;
            current.requestFocus();
        }
        resetDisplay();
        showCompare("", "");
    }

    private void clearAll() {
        for (Row r : rows) {
            r.edit.setText("");
        }
        showCompare("", "");
        current = rows.get(0).edit;
        current.requestFocus();
    }

    // ---------------------------------------------------------------- 结果显示

    private void onEdited(Row row) {
        String text = row.edit.getText().toString();
        row.value = null;
        row.error = false;
        if (!text.trim().isEmpty()) {
            BigDecimal v = ExprParser.evaluate(text);
            if (v == null) {
                row.error = true;
            } else {
                row.value = ExprParser.format(v);
            }
        }
        resetDisplay();
        showCompare("", "");
    }

    private void resetDisplay() {
        for (Row r : rows) {
            render(r, "", R.color.result_default, false);
        }
    }

    private void render(Row r, String tag, int colorRes, boolean bold) {
        if (r.value != null) {
            r.result.setText("= " + r.value + tag);
        } else {
            r.result.setText(r.error ? "…" : "");
        }
        r.result.setTextColor(color(colorRes));
        r.result.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
    }

    // ---------------------------------------------------------------- 比较

    private void compare() {
        List<Integer> ids = new ArrayList<>();
        List<String> exprs = new ArrayList<>();
        final List<BigDecimal> vals = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            String t = rows.get(i).edit.getText().toString();
            if (t.trim().isEmpty()) {
                continue;
            }
            BigDecimal v = ExprParser.evaluate(t);
            if (v == null) {
                showCompare("第 " + LABELS[i] + " 行的算式有误，请检查。", "");
                return;
            }
            ids.add(i);
            exprs.add(t.trim());
            vals.add(v);
        }
        if (ids.size() < 2) {
            showCompare("至少填写两个算式才能比较。", "");
            return;
        }

        List<Integer> order = new ArrayList<>();
        for (int k = 0; k < ids.size(); k++) {
            order.add(k);
        }
        Collections.sort(order, (x, y) -> vals.get(y).compareTo(vals.get(x)));

        StringBuilder chain = new StringBuilder();
        for (int k = 0; k < order.size(); k++) {
            int cur = order.get(k);
            if (k > 0) {
                int prev = order.get(k - 1);
                chain.append(vals.get(prev).compareTo(vals.get(cur)) == 0 ? " = " : " > ");
            }
            chain.append(LABELS[ids.get(cur)]);
        }

        BigDecimal max = vals.get(order.get(0));
        BigDecimal min = vals.get(order.get(order.size() - 1));
        boolean allEqual = max.compareTo(min) == 0;

        // 标出最大、最小
        for (int k = 0; k < ids.size(); k++) {
            Row r = rows.get(ids.get(k));
            BigDecimal v = vals.get(k);
            if (allEqual) {
                render(r, "", R.color.result_default, false);
            } else if (v.compareTo(max) == 0) {
                render(r, "（最大）", R.color.max_color, true);
            } else if (v.compareTo(min) == 0) {
                render(r, "（最小）", R.color.min_color, true);
            } else {
                render(r, "", R.color.result_default, false);
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("大小顺序（从大到小）：\n").append(chain).append("\n\n");
        if (allEqual) {
            sb.append("所有结果相等");
        } else {
            sb.append("最大：").append(names(ids, vals, max))
                    .append("（").append(ExprParser.format(max)).append("）\n");
            sb.append("最小：").append(names(ids, vals, min))
                    .append("（").append(ExprParser.format(min)).append("）\n");
            sb.append("最大与最小相差：").append(ExprParser.format(max.subtract(min)));
            if (min.signum() > 0) {
                BigDecimal ratio = max.divide(min, 2, RoundingMode.HALF_UP);
                sb.append("\n最大是最小的 ").append(ExprParser.format(ratio)).append(" 倍");
            }
        }

        addHistory(exprs);
        String summary = sb.toString();
        showCompare(summary, summary);
    }

    private String names(List<Integer> ids, List<BigDecimal> vals, BigDecimal target) {
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < ids.size(); k++) {
            if (vals.get(k).compareTo(target) == 0) {
                if (sb.length() > 0) {
                    sb.append("、");
                }
                sb.append(LABELS[ids.get(k)]);
            }
        }
        return sb.toString();
    }

    private void showCompare(String text, String copyText) {
        compareCopyText = copyText;
        if (copyText.isEmpty()) {
            compareView.setText(text);
        } else {
            compareView.setText(text + "\n\n（点这里可复制）");
            scroll.post(() -> scroll.smoothScrollTo(0, 100000));
        }
        if (!text.isEmpty() && copyText.isEmpty()) {
            scroll.post(() -> scroll.smoothScrollTo(0, 100000));
        }
    }

    // ---------------------------------------------------------------- 保存与历史

    private void saveState() {
        JSONArray a = new JSONArray();
        for (Row r : rows) {
            a.put(r.edit.getText().toString());
        }
        prefs.edit().putString(KEY_STATE, a.toString()).apply();
    }

    private List<String> loadState() {
        List<String> list = new ArrayList<>();
        String s = prefs.getString(KEY_STATE, null);
        if (s != null) {
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) {
                    list.add(a.optString(i, ""));
                }
            } catch (JSONException ignored) {
                list.clear();
            }
        }
        if (list.isEmpty()) {
            for (int i = 0; i < DEFAULT_ROWS; i++) {
                list.add("");
            }
        }
        return list;
    }

    private JSONArray loadHistory() {
        String s = prefs.getString(KEY_HISTORY, null);
        if (s == null) {
            return new JSONArray();
        }
        try {
            return new JSONArray(s);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private void addHistory(List<String> exprs) {
        JSONArray old = loadHistory();
        JSONArray entry = new JSONArray();
        for (String e : exprs) {
            entry.put(e);
        }
        JSONArray out = new JSONArray();
        out.put(entry);
        for (int i = 0; i < old.length() && out.length() < MAX_HISTORY; i++) {
            JSONArray o = old.optJSONArray(i);
            if (o == null) {
                continue;
            }
            if (i == 0 && o.toString().equals(entry.toString())) {
                continue;
            }
            out.put(o);
        }
        prefs.edit().putString(KEY_HISTORY, out.toString()).apply();
    }

    private List<String> entryToList(JSONArray a) {
        List<String> list = new ArrayList<>();
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                list.add(a.optString(i, ""));
            }
        }
        return list;
    }

    private void showHistory() {
        final JSONArray h = loadHistory();
        if (h.length() == 0) {
            toast("还没有历史记录，先比较一次吧");
            return;
        }
        String[] items = new String[h.length()];
        for (int i = 0; i < h.length(); i++) {
            StringBuilder jb = new StringBuilder();
            for (String ex : entryToList(h.optJSONArray(i))) {
                if (jb.length() > 0) {
                    jb.append("  |  ");
                }
                jb.append(ex);
            }
            String joined = jb.toString();
            if (joined.length() > 80) {
                joined = joined.substring(0, 80) + "…";
            }
            items[i] = joined;
        }
        new AlertDialog.Builder(this)
                .setTitle("历史记录（点一条载入）")
                .setItems(items, (d, which) -> loadRows(entryToList(h.optJSONArray(which))))
                .setNeutralButton("清除历史", (d, w) -> {
                    prefs.edit().remove(KEY_HISTORY).apply();
                    toast("历史已清除");
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    // ---------------------------------------------------------------- 键盘

    private View buildKeypad() {
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(dp(6), dp(6), dp(6), dp(6));

        String[][] keys = {
                {"7", "8", "9", "\u00f7", "\u2190"},
                {"4", "5", "6", "\u00d7", "("},
                {"1", "2", "3", "\u2212", ")"},
                {"0", ".", "+", "%", "清行"}
        };

        for (String[] rowKeys : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (String key : rowKeys) {
                Button b = makeKey(key);
                b.setOnClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    onKey(key);
                });
                row.addView(b, new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
            }
            pad.addView(row, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));
        }

        LinearLayout last = new LinearLayout(this);
        last.setOrientation(LinearLayout.HORIZONTAL);

        Button clearBtn = makeKey("清空");
        clearBtn.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            clearAll();
        });
        last.addView(clearBtn, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        Button compareBtn = makeKey("比较");
        compareBtn.setTypeface(null, Typeface.BOLD);
        compareBtn.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            compare();
        });
        last.addView(compareBtn, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 2f));

        pad.addView(last, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));
        return pad;
    }

    private Button makeKey(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private void onKey(String key) {
        if (current == null) {
            return;
        }
        switch (key) {
            case "\u2190":
                backspace();
                break;
            case "清行":
                current.setText("");
                break;
            default:
                insert(key);
                break;
        }
    }

    private void insert(String t) {
        EditText e = current;
        int a = Math.max(e.getSelectionStart(), 0);
        int b = Math.max(e.getSelectionEnd(), 0);
        int start = Math.min(a, b);
        int end = Math.max(a, b);
        e.getText().replace(start, end, t);
        e.setSelection(start + t.length());
    }

    private void backspace() {
        EditText e = current;
        int a = Math.max(e.getSelectionStart(), 0);
        int b = Math.max(e.getSelectionEnd(), 0);
        int start = Math.min(a, b);
        int end = Math.max(a, b);
        if (start != end) {
            e.getText().delete(start, end);
            e.setSelection(start);
        } else if (start > 0) {
            e.getText().delete(start - 1, start);
            e.setSelection(start - 1);
        }
    }

    // ---------------------------------------------------------------- 工具

    private void copy(String text, String message) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("result", text));
            toast(message);
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int color(int resId) {
        return getResources().getColor(resId, getTheme());
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
