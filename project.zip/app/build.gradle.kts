plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.comparecalc"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.comparecalc"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
}
